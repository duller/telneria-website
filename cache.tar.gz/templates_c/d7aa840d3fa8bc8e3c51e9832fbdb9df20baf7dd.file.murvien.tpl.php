<?php /* Smarty version Smarty-3.1.7, created on 2012-09-02 00:02:24
         compiled from "templates/menuLateral/races/murvien.tpl" */ ?>
<?php /*%%SmartyHeaderCode:8924133355026c40bb8f012-24404336%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd7aa840d3fa8bc8e3c51e9832fbdb9df20baf7dd' => 
    array (
      0 => 'templates/menuLateral/races/murvien.tpl',
      1 => 1345993733,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '8924133355026c40bb8f012-24404336',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5026c40bbbeb4',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5026c40bbbeb4')) {function content_5026c40bbbeb4($_smarty_tpl) {?><div class="descriptionClasse">
<h3>Les Murviens</h3>
<p>Les murviens sont des créatures humanoïdes à quatre bras et quatre yeux qui peuvent se régénérer et qui ont une affinité avec la magie offensive.</p>
<h4>Traits raciaux</h4>
<p>+1 au dé de toucher avec les sorts offensifs, respire sous l'eau, peut récupérer 1d4 de vie recouvrée après un combat, insensible à la peur et au charme, taille moyenne.</p>
<h4>Classes disponibles</h4>
<p><a href="?Page=menuLateral/classes/magicien">Magicien</a>, <a href="?Page=menuLateral/classes/rodeur">rôdeur</a>, <a href="?Page=menuLateral/classes/roublard">roublard</a>,
<a href="?Page=menuLateral/classes/sorcier">sorcier</a>.</p>
</div>

<div class="classeImage">
    <p><img class="imagePersonnage" src="ressources/ImagesRaces/MurvienSorcier.jpg"></p>
    <p>Un murvien sorcier</p>
</div>
<?php }} ?>
<?php /* Smarty version Smarty-3.1.7, created on 2012-08-11 15:26:05
         compiled from "templates/classesJdr/roublard.tpl" */ ?>
<?php /*%%SmartyHeaderCode:75429171250265d6d66b767-51225286%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '95e365852f7eda93387fd065591fe466b6473319' => 
    array (
      0 => 'templates/classesJdr/roublard.tpl',
      1 => 1344691056,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '75429171250265d6d66b767-51225286',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_50265d6d6a9a0',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_50265d6d6a9a0')) {function content_50265d6d6a9a0($_smarty_tpl) {?>
	<h4>Description</h4>
	<p>
	</p>

	<h4>Armures</h4>
	<p>Tissu, cuir.</p>

	<h4>Armes</h4>
	<p>Dagues, épées à une main, masses à une main, haches à une main, arcs.</p>

	<h4>Alignement</h4>
	<p>Habituellement chaotique neutre, ne peut pas être loyal.</p>

	<h4>Caractéristiques</h4>
	<p>
	<table>
		<tr>
			<td>
				<p class="ptab">Base de points de vie</p>
			</td>
			<td>
				<p class="ptab">4</p>
			</td>
		</tr>
	</table>
	<br />
	<table>
		<tr>
			<td>
				<p class="ptab">Force</p>
			</td>
			<td>
				<p class="ptab">6</p>
			</td>
		</tr>
		<tr>
			<td>
				<p class="ptab">Dexterité</p>
			</td>
			<td>
				<p class="ptab">10</p>
			</td>
		</tr>
		<tr>
			<td>
				<p class="ptab">Constitution</p>
			</td>
			<td>
				<p class="ptab">8</p>
			</td>
		</tr>
		<tr>
			<td>
				<p class="ptab">Intelligence</p>
			</td>
			<td>
				<p class="ptab">5</p>
			</td>
		</tr>
		<tr>
			<td>
				<p class="ptab">Sagesse</p>
			</td>
			<td>
				<p class="ptab">6</p>
			</td>
		</tr>
		<tr>
			<td>
				<p class="ptab">Charisme</p>
			</td>
			<td>
				<p class="ptab">5</p>
			</td>
		</tr>
	</table>

	
	<br />

	</p>

	<h4>Dons</h4>
	<p>Sauvegarde, combat.</p>

	<h4>Compétences</h4>
	<p>Crochetage, équilibre, discrétion.</p>

	<h4>Sorts et techniques</h4>
	<p>Aucun sort.</p>

	<h4>Classes de prestige</h4>
	<p>Assassin, fourbe.</p>

	<h4>Spécificités</h4>
	<p>Utilise son coefficient de dexterité pour les chances de toucher au corps-à-corps.</p>
<?php }} ?>
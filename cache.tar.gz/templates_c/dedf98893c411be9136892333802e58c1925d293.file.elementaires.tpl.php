<?php /* Smarty version Smarty-3.1.7, created on 2012-08-11 23:39:18
         compiled from "templates/menuLateral/monstres/elementaires.tpl" */ ?>
<?php /*%%SmartyHeaderCode:753588235026d1067906f8-09875368%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'dedf98893c411be9136892333802e58c1925d293' => 
    array (
      0 => 'templates/menuLateral/monstres/elementaires.tpl',
      1 => 1344709072,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '753588235026d1067906f8-09875368',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5026d1067915f',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5026d1067915f')) {function content_5026d1067915f($_smarty_tpl) {?><?php }} ?>
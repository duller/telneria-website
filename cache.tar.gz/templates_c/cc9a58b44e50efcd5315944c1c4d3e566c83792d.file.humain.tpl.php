<?php /* Smarty version Smarty-3.1.7, created on 2012-09-01 23:58:17
         compiled from "templates/menuLateral/races/humain.tpl" */ ?>
<?php /*%%SmartyHeaderCode:17515687435026c3f37a8c46-03797378%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'cc9a58b44e50efcd5315944c1c4d3e566c83792d' => 
    array (
      0 => 'templates/menuLateral/races/humain.tpl',
      1 => 1345993733,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '17515687435026c3f37a8c46-03797378',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5026c3f37d74b',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5026c3f37d74b')) {function content_5026c3f37d74b($_smarty_tpl) {?><div class="descriptionClasse">
<h3>Les Humains</h3>
<p>Les humains sont des créatures communes et classiques.</p>
<h4>Traits raciaux</h4>
<p>+1 en sagesse, +1 au dé de toucher avec les masses et les épées, taille moyenne.</p>
<h4>Classes disponibles</h4>
<p><a href="?Page=menuLateral/classes/clerc">Clerc</a>, <a href="?Page=menuLateral/classes/guerrier">guerrier</a>, <a href="?Page=menuLateral/classes/magicien">magicien</a>,
<a href="?Page=menuLateral/classes/paladin">paladin</a>, <a href="?Page=menuLateral/classes/rodeur">rôdeur</a>, <a href="?Page=menuLateral/classes/roublard">roublard</a>,
<a href="?Page=menuLateral/classes/sombregarde">sombregarde</a>, <a href="?Page=menuLateral/classes/sorcier">sorcier</a>.</p>
</div>

<div class="classeImage">
    <p><img class="imagePersonnage" src="ressources/ImagesRaces/HumainPaladin.jpg"></p>
    <p>Un humain paladin</p>
</div>
<?php }} ?>
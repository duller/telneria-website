<?php /* Smarty version Smarty-3.1.7, created on 2012-08-26 17:08:57
         compiled from "templates/menuLateral/races/kerfenn.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2315677985026c3fa3d4389-66522534%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0898f4df82fbaeaf184f1cfaa41b429e9fc066da' => 
    array (
      0 => 'templates/menuLateral/races/kerfenn.tpl',
      1 => 1345993733,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2315677985026c3fa3d4389-66522534',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5026c3fa404b4',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5026c3fa404b4')) {function content_5026c3fa404b4($_smarty_tpl) {?><div class="descriptionClasse">
<h3>Les Kerfenn</h3>
<p>Les kerfenn sont de petites créatures qui comptent sur leur ingéniosité pour compenser leurs faiblesses physiques.</p>
<h4>Traits raciaux</h4>
<p>+1 en intelligence, +1 en sagesse, artisanat amélioré, discrétion améliorée, taille petite.</p>
<h4>Classes disponibles</h4>
<p><a href="?Page=menuLateral/classes/magicien">Magicien</a>, <a href="?Page=menuLateral/classes/roublard">roublard</a>, <a href="?Page=menuLateral/classes/sorcier">sorcier</a>.</p>
</div>

<div class="classeImage">
    <p><img class="imagePersonnage" src="ressources/ImagesRaces/KerfennMagicien.jpg"></p>
    <p>Un kerfenn magicien</p>
</div>
<?php }} ?>
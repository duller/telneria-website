<?php /* Smarty version Smarty-3.1.7, created on 2012-09-22 19:26:52
         compiled from "templates/menuLateral/monstres/betes.tpl" */ ?>
<?php /*%%SmartyHeaderCode:33859764350279d56795789-64882399%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '49a1d15ce7da273ba89c86bb3cc2790befed1907' => 
    array (
      0 => 'templates/menuLateral/monstres/betes.tpl',
      1 => 1348334810,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '33859764350279d56795789-64882399',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_50279d5679646',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_50279d5679646')) {function content_50279d5679646($_smarty_tpl) {?><h1>Les bêtes</h1><?php }} ?>
<?php /* Smarty version Smarty-3.1.7, created on 2012-08-12 00:07:56
         compiled from "templates/menuLateral/monstres/mortVivants.tpl" */ ?>
<?php /*%%SmartyHeaderCode:12915669225026d7bcdee926-45122974%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '16ad3e28e9202061410e1d8663cd81eef9973391' => 
    array (
      0 => 'templates/menuLateral/monstres/mortVivants.tpl',
      1 => 1344708990,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12915669225026d7bcdee926-45122974',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5026d7bcdef68',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5026d7bcdef68')) {function content_5026d7bcdef68($_smarty_tpl) {?><?php }} ?>
<?php /* Smarty version Smarty-3.1.7, created on 2012-08-26 17:01:44
         compiled from "templates/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:3376726134fa149d2f1fa71-62941223%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9206ffe216f3f7c2e7655782292928f7d20e8be5' => 
    array (
      0 => 'templates/footer.tpl',
      1 => 1345993304,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3376726134fa149d2f1fa71-62941223',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_4fa149d2f24bb',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_4fa149d2f24bb')) {function content_4fa149d2f24bb($_smarty_tpl) {?>

<p>
<a class="lienBlanc" href="?Page=fiches/mentionslegales">Mentions légales - Contact</a>
</p><?php }} ?>
<?php /* Smarty version Smarty-3.1.7, created on 2012-08-13 22:53:22
         compiled from "templates/gestionCompte/perdu.tpl" */ ?>
<?php /*%%SmartyHeaderCode:201715439250296942936ab8-17563649%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8ae2d8b331e27687c5ad50f3eb91830b54557327' => 
    array (
      0 => 'templates/gestionCompte/perdu.tpl',
      1 => 1343420742,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '201715439250296942936ab8-17563649',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_502969429a7d2',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_502969429a7d2')) {function content_502969429a7d2($_smarty_tpl) {?>
<h1>Récupération de mot de passe</h1>

<p>Non implementé</p><?php }} ?>
<?php /* Smarty version Smarty-3.1.7, created on 2012-08-26 17:01:19
         compiled from "templates/fiches/mentionslegales.tpl" */ ?>
<?php /*%%SmartyHeaderCode:881657645026ab601da543-14895455%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0e566f6ca9beab67f43606823c7ba046df562b85' => 
    array (
      0 => 'templates/fiches/mentionslegales.tpl',
      1 => 1345993277,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '881657645026ab601da543-14895455',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5026ab6020d04',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5026ab6020d04')) {function content_5026ab6020d04($_smarty_tpl) {?>
<h1>Mentions légales</h1>
<h2>Le code source</h2>
<p>Le code source de ce site web, à savoir le code html, css, javascript et php, est sous licence GPL V3.</p>
<p>Code source : François Ripp.</p>

<h2>Le contenu</h2>
<p>Le contenu culturel et artistique, à savoir le texte inclus dans les balises de paragraphe et les illustrations
    sont sous licence CC-by-nc-sa 2.0 .</p>
<p>Textes : François Ripp.</p>
<p>Illustrations : Jérôme Rotfarb.</p>

<h3>Contact</h3>
<p>Pour toute question, vous pouvez contacter l'auteur du site à l'adresse suivante : 
    <a href="mailo:francois.commerce@gmail.com">francois.commerce@gmail.com</mailto></p><?php }} ?>
<?php /* Smarty version Smarty-3.1.7, created on 2012-08-11 22:54:32
         compiled from "templates/menuLateral/equipement/armes.tpl" */ ?>
<?php /*%%SmartyHeaderCode:15446779035026ab182691b0-59605552%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7e79b3898715d2519a2e6bb360141263de252790' => 
    array (
      0 => 'templates/menuLateral/equipement/armes.tpl',
      1 => 1344718470,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '15446779035026ab182691b0-59605552',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5026ab182983c',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5026ab182983c')) {function content_5026ab182983c($_smarty_tpl) {?> i. Les épées<br />
 a) A une main<br />
Epée fine rouillée, 1d2, 10po.<br />
Epée fine aiguisée, 1d4, 25po.<br />
Lame d'acier trempée, 1d6, 40po.<br />
 b) A deux mains<br />
Grande épée abîmée, 1d6, 20po.<br />
Epée large forgée, 1d8, 35po.<br />
Espadon tranchant, 1d10, 60po.<br /><br />
 ii. Les haches<br />
 a) A une main<br />
Petite hache en silex, 1d2, 10po.<br />
Hache moyenne en fer, 1d4, 25po.<br />
Hache tranchante équilibrée, 1d6, 60po.<br />
 b) A deux mains<br />
Hache massive grossière, 1d6, 20po.<br />
Hache double en acier, 1d8, 35po.<br />
Hache lourde des montagnes, 1d10, 60po.<br /><br />
 iii. Les masses<br />
 a) A une main<br />
Masse légère, 1d2, 10po.<br />
Masse barbelée, 1d4, 25po.<br />
Morgenstern, 1d6, 40po.<br />
 b) A deux mains<br />
Cognée renforcée, 1d6, 20po.<br />
Marteau de forgeron, 1d8, 35po.<br />
Grande masse de guerre, 1d10, 60po.<br /><br />
 iv. Les armes d'hast<br />
Lance taillée, 1d6, 20po.<br />
Longue lance forgée, 1d8, 35po.<br />
Hallebarde, 1d10, 60po.<br /><br />
 v. Les dagues<br />
Petite dague, 1d2, 10po.<br />
Moyenne dague, 1d4, 25po.<br />
Forte dague, 1d6, 40po.<br /><br />
 vi. Les bâtons<br />
Bâton sylvestre, 1d6, 20po.<br />
Bâton en chêne taillé, 1d8, 35po.<br />
Bâton runique, 1d10, 60po.<br /><br />
 vii. Les baguettes<br />
Baguette en bois d'if, 1d4, 20m, 10po.<br /><br />
 viii. Les arcs<br />
Arc court en écorce, 1d6, 25m, 25po.<br />
Arc long en sapin, 1d8, 30m, 40po.<br />
Arc composite, 1d10, 30m, 60po. <br /><br />
 ix. Les arbalètes<br />
Arbalète légère, 1d6, 30m, 35po.<br />
Arbalète lourde, 1d8, 35m, 45po.<br />
Arbalète lourde renforcée, 1d10, 40m, 65po.<br /><?php }} ?>
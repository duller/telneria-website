<?php /* Smarty version Smarty-3.1.7, created on 2012-09-22 14:58:00
         compiled from "templates/menuLateral/telneria.tpl" */ ?>
<?php /*%%SmartyHeaderCode:672210081505db5d8a623e3-11152825%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ea20e2c5e9d75727b5b44b042f449eee51202896' => 
    array (
      0 => 'templates/menuLateral/telneria.tpl',
      1 => 1348318628,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '672210081505db5d8a623e3-11152825',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_505db5d8a9652',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_505db5d8a9652')) {function content_505db5d8a9652($_smarty_tpl) {?><h1>Le monde de Telneria</h1>

<p>Quatre continents : Istnor, Veldris, Mestrhune et Ferestos.</p><?php }} ?>
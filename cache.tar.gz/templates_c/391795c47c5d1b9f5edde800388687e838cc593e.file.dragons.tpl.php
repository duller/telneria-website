<?php /* Smarty version Smarty-3.1.7, created on 2012-09-22 19:26:54
         compiled from "templates/menuLateral/monstres/dragons.tpl" */ ?>
<?php /*%%SmartyHeaderCode:20991803505026b19e0bac28-28338164%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '391795c47c5d1b9f5edde800388687e838cc593e' => 
    array (
      0 => 'templates/menuLateral/monstres/dragons.tpl',
      1 => 1348334810,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20991803505026b19e0bac28-28338164',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5026b19e0bba4',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5026b19e0bba4')) {function content_5026b19e0bba4($_smarty_tpl) {?><h1>Les dragons</h1><?php }} ?>
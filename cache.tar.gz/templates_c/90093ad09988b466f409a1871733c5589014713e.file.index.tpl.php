<?php /* Smarty version Smarty-3.1.7, created on 2012-08-26 16:58:28
         compiled from "templates/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:4482397884fa149d2d28008-41449651%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '90093ad09988b466f409a1871733c5589014713e' => 
    array (
      0 => 'templates/index.tpl',
      1 => 1345993108,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '4482397884fa149d2d28008-41449651',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_4fa149d2ea19e',
  'variables' => 
  array (
    'nom' => 0,
    'page' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_4fa149d2ea19e')) {function content_4fa149d2ea19e($_smarty_tpl) {?>
<!DOCTYPE html>
<html>
   <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <meta http-equiv="Content-Language" content="fr">

        <meta name="keywords" lang="fr" content="jeu de rôle, medieval, fantasy">
        <meta name="description" content="Les légendes de Telnaria - le site internet">
                
        <link rel="stylesheet" href="style/layout.css">
        <link rel="stylesheet" href="style/style.css">
        <link rel="stylesheet" href="style/formulaire.css">
        <script type="text/javascript" src="js/Jquery.js"></script>
        <title><?php echo $_smarty_tpl->tpl_vars['nom']->value;?>
</title>
    </head>

    <body>
        <div id="header"><?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
</div>
        <div id="topmenu"><?php echo $_smarty_tpl->getSubTemplate ("topmenu.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
</div>
        <div id="menu"><?php echo $_smarty_tpl->getSubTemplate ("menu.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
</div>
        <div id="content"><?php echo $_smarty_tpl->getSubTemplate ($_smarty_tpl->tpl_vars['page']->value, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
</div>
    	<div id="footer"><?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
</div>
        <div id="hidden">François Ripp, Jérôme Rotfarb : Creative Commons by-nc-sa & GPL V3</div>
    </body>
</html>

<?php }} ?>
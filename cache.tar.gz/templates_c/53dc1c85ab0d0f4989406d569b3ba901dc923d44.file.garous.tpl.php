<?php /* Smarty version Smarty-3.1.7, created on 2012-09-22 19:26:57
         compiled from "templates/menuLateral/monstres/garous.tpl" */ ?>
<?php /*%%SmartyHeaderCode:8370686385026adad38d8d8-44575735%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '53dc1c85ab0d0f4989406d569b3ba901dc923d44' => 
    array (
      0 => 'templates/menuLateral/monstres/garous.tpl',
      1 => 1348334810,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '8370686385026adad38d8d8-44575735',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5026adad38e67',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5026adad38e67')) {function content_5026adad38e67($_smarty_tpl) {?><h1>Les garous</h1><?php }} ?>
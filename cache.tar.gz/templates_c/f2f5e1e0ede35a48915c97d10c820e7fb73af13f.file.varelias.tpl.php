<?php /* Smarty version Smarty-3.1.7, created on 2012-08-13 22:45:31
         compiled from "templates/menuLateral/races/varelias.tpl" */ ?>
<?php /*%%SmartyHeaderCode:6885476755026bfe1deb043-82700578%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f2f5e1e0ede35a48915c97d10c820e7fb73af13f' => 
    array (
      0 => 'templates/menuLateral/races/varelias.tpl',
      1 => 1344890724,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6885476755026bfe1deb043-82700578',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5026bfe1debe6',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5026bfe1debe6')) {function content_5026bfe1debe6($_smarty_tpl) {?><div class="descriptionClasse">
<h3>Les Varelias</h3>
<p>Les varelias sont d'imposants humanoïdes dont l'épiderme s'apparente à l'écorce des arbres. Ils sont proches de la nature, anciens et sages.</p>
<h4>Traits raciaux</h4>
<p>+1 à la constitution, +1 à la force, +1 en sagesse, +1 au dé de toucher avec les sorts de soins, peut s'imprégner de la nature pour recouvrer 1d4 de vie après un combat s'il se situe à proximité de la végétation, taille grande.</p>
<h4>Classes disponibles</h4>
<p><a href="?Page=menuLateral/classes/chaman">Chaman</a>, <a href="?Page=menuLateral/classes/druide">druide</a>,
    <a href="?Page=menuLateral/classes/guerrier">guerrier</a>, <a href="?Page=menuLateral/classes/rodeur">rôdeur</a>.</p>
</div>

<div class="classeImage">
    <p><img class="imagePersonnage" src="ressources/draconide.jpg"></p>
    <p>Un varelias druide</p>
</div>
<?php }} ?>
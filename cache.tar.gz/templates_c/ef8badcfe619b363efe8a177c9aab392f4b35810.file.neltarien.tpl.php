<?php /* Smarty version Smarty-3.1.7, created on 2012-09-22 14:41:02
         compiled from "templates/menuLateral/races/neltarien.tpl" */ ?>
<?php /*%%SmartyHeaderCode:476408008502965aecb1299-46781438%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ef8badcfe619b363efe8a177c9aab392f4b35810' => 
    array (
      0 => 'templates/menuLateral/races/neltarien.tpl',
      1 => 1345993733,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '476408008502965aecb1299-46781438',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_502965aece071',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_502965aece071')) {function content_502965aece071($_smarty_tpl) {?><div class="descriptionClasse">
<h3>Les Neltariens</h3>
<p>Les neltariens sont les cousins sombres des elfes, ils sont plus grands mais conservent une allure élancée.</p>
<h4>Traits raciaux</h4>
<p>+1 en charisme, +1 en dextérité, vision nocturne développée, discrétion améliorée la nuit, taille moyenne.</p>
<h4>Classes disponibles</h4>
<p><a href="?Page=menuLateral/classes/guerrier">Guerrier</a>, <a href="?Page=menuLateral/classes/magicien">magicien</a>, <a href="?Page=menuLateral/classes/rodeur">rôdeur</a>,
    <a href="?Page=menuLateral/classes/roublard">roublard</a>, <a href="?Page=menuLateral/classes/sombregarde">sombregarde</a>, <a href="?Page=menuLateral/classes/sorcier">sorcier</a>.</p>
</div>

<div class="classeImage">
    <p><img class="imagePersonnage" src="ressources/ImagesRaces/NeltarienneRoublarde.jpg"></p>
    <p>Une neltarienne roublarde</p>
</div>
<?php }} ?>
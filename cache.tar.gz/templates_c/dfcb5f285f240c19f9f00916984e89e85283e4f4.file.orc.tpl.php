<?php /* Smarty version Smarty-3.1.7, created on 2012-08-26 17:09:00
         compiled from "templates/menuLateral/races/orc.tpl" */ ?>
<?php /*%%SmartyHeaderCode:15531246215026c4024404a9-53033912%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'dfcb5f285f240c19f9f00916984e89e85283e4f4' => 
    array (
      0 => 'templates/menuLateral/races/orc.tpl',
      1 => 1345993733,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '15531246215026c4024404a9-53033912',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5026c40247146',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5026c40247146')) {function content_5026c40247146($_smarty_tpl) {?><div class="descriptionClasse">
<h3>Les Orcs</h3>
<p>Les orcs sont de robustes combattants à la peau verte.</p>
<h4>Traits raciaux</h4>
<p>+1 à la force, +1 à la constitution, +1 au dé de toucher avec les haches, 1d4 supplémentaire aux dégâts si les pv de l'orc sont inférieurs à 20% du total, taille moyenne.</p>
<h4>Classes disponibles</h4>
<p><a href="?Page=menuLateral/classes/chaman">Chaman</a>, <a href="?Page=menuLateral/classes/guerrier">guerrier</a>, <a href="?Page=menuLateral/classes/sombregarde">sombregarde</a>,
    <a href="?Page=menuLateral/classes/sorcier">sorcier</a>.</p>
</div>

<div class="classeImage">
    <p><img class="imagePersonnage" src="ressources/ImagesRaces/OrcGuerrier.jpg"></p>
    <p>Un orc guerrier</p>
</div>
<?php }} ?>
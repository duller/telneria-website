<?php /* Smarty version Smarty-3.1.7, created on 2012-08-11 21:03:49
         compiled from "templates/gestionCompte/connexion.tpl" */ ?>
<?php /*%%SmartyHeaderCode:20135898275026ac95e94d76-41042452%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9b08e041d947d67b3940932381130f8b602e8e82' => 
    array (
      0 => 'templates/gestionCompte/connexion.tpl',
      1 => 1344710364,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20135898275026ac95e94d76-41042452',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5026ac95ec743',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5026ac95ec743')) {function content_5026ac95ec743($_smarty_tpl) {?>

<script type="text/javascript">

        function formVerification()
        {
                var ok = true;

                // Login
                if (! /^[a-zA-Z0-9_-]{3,16}$/.test(document.getElementById("login").value))
                {
                    document.getElementById("erreurlogin").className = "erreurAffiche";
                    ok = false;
                }
                else
                {
                    document.getElementById("erreurlogin").className = "erreurMasque";
                }

                // Mot de passe
                if (! /^[a-zA-Z0-9_-]{6,18}$/.test(document.getElementById("motdepasse").value))
                {
                    document.getElementById("erreurmotdepasse").className = "erreurAffiche";
                    ok = false;
                }
                else
                {
                    document.getElementById("erreurmotdepasse").className = "erreurMasque";
                }
                    
                return ok;
        }

</script>


<h1>Connexion</h1>

<form action="?Page=gestionCompte/authentification" method="POST" onsubmit="return formVerification()">
    <table>
        <tr>
            <td>
                <label for="login">Login</label>
            </td>

            <td>
                <input name="login" id="login" type="text">
            </td>
            <td>
                <span class="erreurMasque" id="erreurlogin"> (3 à 16 caractères alphanumériques)</span>
            </td>
        </tr>
        <tr>
            <td>
                <label for="motdepasse">Mot de passe</label>
            </td>

            <td>
                <input name="motdepasse" id="motdepasse" type="password">
            </td>
            <td>
                <span class="erreurMasque" id="erreurmotdepasse"> (6 à 16 caractères alphanumériques)</span>
            </td>
        </tr>
        <tr>
            <td>
            </td>

            <td>
                <input id="envoi" value="Authentification" type="submit">
            </td>
            <td>
            </td>
        </tr>
        <tr>
            <td>
                Pas de compte
            </td>

            <td>
                <a href="?Page=gestionCompte/inscription">Inscription</a>
            </td>
            <td>
            </td>
        </tr>
        <tr>
            <td>
                Mot de passe perdu
            </td>

            <td>
                <a href="?Page=gestionCompte/perdu">Récupérer mon mot de passe</a>
            </td>
            <td>
            </td>
        </tr>
    </table>
</form><?php }} ?>
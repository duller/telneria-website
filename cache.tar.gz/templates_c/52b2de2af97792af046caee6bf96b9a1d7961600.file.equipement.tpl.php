<?php /* Smarty version Smarty-3.1.7, created on 2012-08-11 21:03:16
         compiled from "templates/menuLateral/equipement.tpl" */ ?>
<?php /*%%SmartyHeaderCode:3259824895026ab12e48b94-25954469%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '52b2de2af97792af046caee6bf96b9a1d7961600' => 
    array (
      0 => 'templates/menuLateral/equipement.tpl',
      1 => 1344711793,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3259824895026ab12e48b94-25954469',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5026ab12e790d',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5026ab12e790d')) {function content_5026ab12e790d($_smarty_tpl) {?><h1>L'équipement</h1>

<p>
<a href="?Page=menuLateral/equipement/armes"> Les armes</a>
<br />
<a href="?Page=menuLateral/equipement/armures"> Les armures</a>
</p>
<br /><?php }} ?>
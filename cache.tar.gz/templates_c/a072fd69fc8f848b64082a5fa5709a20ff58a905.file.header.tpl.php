<?php /* Smarty version Smarty-3.1.7, created on 2012-08-11 20:43:37
         compiled from "templates/layout/header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:5536192815026a7d918dd97-25921960%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a072fd69fc8f848b64082a5fa5709a20ff58a905' => 
    array (
      0 => 'templates/layout/header.tpl',
      1 => 1344710364,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '5536192815026a7d918dd97-25921960',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'Connected' => 0,
    'panierNombre' => 0,
    'Login' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5026a7d91a77f',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5026a7d91a77f')) {function content_5026a7d91a77f($_smarty_tpl) {?>
<p>
<a class="lienBlanc" href="?Page=layout/accueil">Accueil</a><br>

<?php if ($_smarty_tpl->tpl_vars['Connected']->value){?>
    <a class="lienBlanc" href="?Page=fiches/panier">Mon panier (<span id="nombreArticle"><?php echo $_smarty_tpl->tpl_vars['panierNombre']->value;?>
</span>)</a><br>
<a class="lienBlanc" href="?Page=gestionCompte/compte">Mon compte (<?php echo $_smarty_tpl->tpl_vars['Login']->value;?>
)</a><br>
<a class="lienBlanc" href="?Page=gestionCompte/authentification">Déconnexion</a><br>
</p>
<?php }else{ ?>
<p>
<a class="lienBlanc" href="?Page=gestionCompte/connexion">Connexion</a><br>
<a class="lienBlanc" href="?Page=gestionCompte/inscription">Inscription</a>
<?php }?>
</p><?php }} ?>
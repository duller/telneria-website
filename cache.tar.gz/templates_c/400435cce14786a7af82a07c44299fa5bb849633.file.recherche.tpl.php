<?php /* Smarty version Smarty-3.1.7, created on 2012-08-11 22:24:39
         compiled from "templates/fiches/recherche.tpl" */ ?>
<?php /*%%SmartyHeaderCode:18743498175026bf87ea9605-00709723%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '400435cce14786a7af82a07c44299fa5bb849633' => 
    array (
      0 => 'templates/fiches/recherche.tpl',
      1 => 1343420742,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '18743498175026bf87ea9605-00709723',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5026bf87ee4d9',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5026bf87ee4d9')) {function content_5026bf87ee4d9($_smarty_tpl) {?>
<h1>Recherche</h1>

<p>Recherche en cours... </p><?php }} ?>
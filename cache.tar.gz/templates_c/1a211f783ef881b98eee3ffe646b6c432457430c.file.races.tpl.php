<?php /* Smarty version Smarty-3.1.7, created on 2012-08-14 16:09:13
         compiled from "templates/menuLateral/races.tpl" */ ?>
<?php /*%%SmartyHeaderCode:7261109655026aa5b130f67-47795996%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1a211f783ef881b98eee3ffe646b6c432457430c' => 
    array (
      0 => 'templates/menuLateral/races.tpl',
      1 => 1344953352,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '7261109655026aa5b130f67-47795996',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5026aa5b1666e',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5026aa5b1666e')) {function content_5026aa5b1666e($_smarty_tpl) {?><h1>Les races</h1>

<p>Le joueur a le choix entre dix races de personnages. Il faut en choisir une, sachant que toutes les races ne donnent pas accès à toutes les classes.</p>

<br />
<h2>Tableau des classes disponibles en fonction des races :</h2>
<br />

<table>
	<tr>
		<td>
		</td>
		<td>
			<p class="ptab"><a href="?Page=menuLateral/races/humain">Humain</a></p>
		</td>
		<td>
			<p class="ptab"><a href="?Page=menuLateral/races/kerfenn">Kerfenn</a></p>
		</td>
		<td>
			<p class="ptab"><a href="?Page=menuLateral/races/nain">Nain</a></p>
		</td>
		<td>
			<p class="ptab"><a href="?Page=menuLateral/races/elfe">Elfe</a></p>
		</td>
		<td>
			<p class="ptab"><a href="?Page=menuLateral/races/orc">Orc</a></p>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Clerc</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
		</td>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Magicien</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Sorcier</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Roublard</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Rôdeur</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Druide</p>
		</td>
		<td>
		</td>
		<td>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Chaman</p>
		</td>
		<td>
		</td>
		<td>
		</td>
		<td>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Guerrier</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Paladin</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
		</td>
		<td>
		</td>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Sombregarde</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
	</tr>
</table>

<br />

<table>
	<tr>
		<td>
		</td>
		<td>
			<p class="ptab"><a href="?Page=menuLateral/races/chepteg">Chepteg</a></p>
		</td>
		<td>
			<p class="ptab"><a href="?Page=menuLateral/races/murvien">Murvien</a></p>
		</td>
		<td>
			<p class="ptab"><a href="?Page=menuLateral/races/varelias">Varelias</a></p>
		</td>
		<td>
			<p class="ptab"><a href="?Page=menuLateral/races/neltarien">Neltarien</a></p>
		</td>
		<td>
			<p class="ptab"><a href="?Page=menuLateral/races/draconide">Draconide</a></p>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Clerc</p>
		</td>
		</td>
		<td>
		</td>
		<td>
		</td>
		<td>
		</td>
		<td>
		</td>
		<td>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Magicien</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>

		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Sorcier</p>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Roublard</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Rôdeur</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Druide</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
		</td>
		<td>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Chaman</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Guerrier</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Paladin</p>
		</td>
		</td>
		<td>
		</td>
		<td>
		</td>
		<td>
		</td>
		<td>
		</td>
		<td>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Sombregarde</p>
		</td>
		<td>
		</td>
		<td>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
		<td>
			<p class="ptab">O</p>
		</td>
	</tr>
</table>

<!--<input type="checkbox" checked="checked" disabled="true"/>--><?php }} ?>
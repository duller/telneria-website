<?php /* Smarty version Smarty-3.1.7, created on 2012-08-11 20:43:37
         compiled from "templates/layout/menu.tpl" */ ?>
<?php /*%%SmartyHeaderCode:4450752245026a7d91b1843-72769704%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8068285b2464bf5c82a23f22013a6c4c2021c84a' => 
    array (
      0 => 'templates/layout/menu.tpl',
      1 => 1344710364,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '4450752245026a7d91b1843-72769704',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5026a7d91b489',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5026a7d91b489')) {function content_5026a7d91b489($_smarty_tpl) {?>
<p>
<a href="?Page=layout/accueil"><span class="menuElement">Accueil</span></a>

<br />
<span class="menuParent">Les personnages</span>
<a href="?Page=catalogue"><span class="menuElement">Création</span></a>
<a href="?Page=classesJdr"><span class="menuElement">Classes</span></a>
<a href="?Page=racesJdr"><span class="menuElement">Races</span></a>

<br />
<span class="menuParent">Les attributs</span>
<a href="?Page=racesJdr"><span class="menuElement">Alignement</span></a>
<a href="?Page=catalogue"><span class="menuElement">Dons</span></a>
<a href="?Page=catalogue"><span class="menuElement">Caractéristiques</span></a>
<a href="?Page=catalogue"><span class="menuElement">Compétences</span></a>

<br />
<span class="menuParent">Le monde</span>
<a href="?Page=catalogue"><span class="menuElement">Équipement</span></a>
<a href="?Page=catalogue"><span class="menuElement">Monstres</span></a>

<br />
<span class="menuParent">Le système de jeu</span>
<a href="?Page=catalogue"><span class="menuElement">Expérience</span></a>
<a href="?Page=catalogue"><span class="menuElement">Combat</span></a>
</p>

        <?php }} ?>
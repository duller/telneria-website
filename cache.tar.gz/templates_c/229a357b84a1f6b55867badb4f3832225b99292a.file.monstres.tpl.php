<?php /* Smarty version Smarty-3.1.7, created on 2012-09-22 19:43:11
         compiled from "templates/menuLateral/monstres.tpl" */ ?>
<?php /*%%SmartyHeaderCode:13521907085026ac7557e3b8-30548278%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '229a357b84a1f6b55867badb4f3832225b99292a' => 
    array (
      0 => 'templates/menuLateral/monstres.tpl',
      1 => 1348335790,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13521907085026ac7557e3b8-30548278',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5026ac755ae9b',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5026ac755ae9b')) {function content_5026ac755ae9b($_smarty_tpl) {?><h1>Les monstres</h1>

<h3>Préparer et gérer les monstres en combat</h3>
<p>Il faut préparer toutes leurs caractéristiques.</p>

<br />
<h3>Les types de monstres</h3>
<p>
<a href="?Page=menuLateral/monstres/betes"> Les bêtes</a>
<br /><br />
<a href="?Page=menuLateral/monstres/demons"> Les démons</a>
<br /><br />
<a href="?Page=menuLateral/monstres/dragons"> Les dragons</a>
<br /><br />
<a href="?Page=menuLateral/monstres/elementaires"> Les élementaires</a>
<br /><br />
<a href="?Page=menuLateral/monstres/etheres"> Les éthérés</a>
<br /><br />
<a href="?Page=menuLateral/monstres/garous"> Les garous</a>
<br /><br />
<a href="?Page=menuLateral/monstres/humanoides"> Les humanoïdes</a>
<br /><br />
<a href="?Page=menuLateral/monstres/mortVivants"> Les mort-vivants</a>
<br /><br />
<a href="?Page=menuLateral/monstres/vampires"> Les vampires</a>
</p>


<br />
<h3>Les monstres personnalisés</h3>

<a href="?Page=menuLateral/monstres/monstresPersonnalises"> Comment créer des monstres personnalisés</a>

<?php }} ?>
<?php /* Smarty version Smarty-3.1.7, created on 2012-08-11 15:26:15
         compiled from "templates/classesJdr/paladin.tpl" */ ?>
<?php /*%%SmartyHeaderCode:203208611050265d77b374e2-99311547%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '42cb9187e3067f85a7ffc9b050b628d181861fc9' => 
    array (
      0 => 'templates/classesJdr/paladin.tpl',
      1 => 1344691056,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '203208611050265d77b374e2-99311547',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_50265d77b706b',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_50265d77b706b')) {function content_50265d77b706b($_smarty_tpl) {?>
	<h4>Description</h4>
	<p>
	</p>

	<h4>Armures</h4>
	<p>Tissu, cuir, maille, plaques, bouclier.</p>

	<h4>Armes</h4>
	<p>Toutes épées, toutes masses, haches à deux mains, armes d'hast.</p>

	<h4>Alignement</h4>
	<p>Habituellement loyal bon, ne peut être ni chaotique, ni mauvais.</p>

	<h4>Caractéristiques</h4>
	<p>
	<table>
		<tr>
			<td>
				<p class="ptab">Base de points de vie</p>
			</td>
			<td>
				<p class="ptab">5</p>
			</td>
		</tr>
		<tr>
			<td>
				<p class="ptab">Base de points de mana</p>
			</td>
			<td>
				<p class="ptab">3</p>
			</td>
		</tr>
	</table>
	<br />
	<table>
		<tr>
			<td>
				<p class="ptab">Force</p>
			</td>
			<td>
				<p class="ptab">7</p>
			</td>
		</tr>
		<tr>
			<td>
				<p class="ptab">Dexterité</p>
			</td>
			<td>
				<p class="ptab">6</p>
			</td>
		</tr>
		<tr>
			<td>
				<p class="ptab">Constitution</p>
			</td>
			<td>
				<p class="ptab">8</p>
			</td>
		</tr>
		<tr>
			<td>
				<p class="ptab">Intelligence</p>
			</td>
			<td>
				<p class="ptab">6</p>
			</td>
		</tr>
		<tr>
			<td>
				<p class="ptab">Sagesse</p>
			</td>
			<td>
				<p class="ptab">6</p>
			</td>
		</tr>
		<tr>
			<td>
				<p class="ptab">Charisme</p>
			</td>
			<td>
				<p class="ptab">7</p>
			</td>
		</tr>
	</table>

	
	<br />

	</p>

	<h4>Dons</h4>
	<p>Sauvegarde, combat, magie.</p>

	<h4>Compétences</h4>
	<p>Diplomatie, psychologie, premiers secours.</p>

	<h4>Sorts et techniques</h4>
	<p>1 en magie blanche, 1 en magie protectrice.</p>

	<h4>Classes de prestige</h4>
	<p>Templier, inquisiteur.</p>
<?php }} ?>
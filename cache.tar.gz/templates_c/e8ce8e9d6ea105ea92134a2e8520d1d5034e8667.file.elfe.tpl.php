<?php /* Smarty version Smarty-3.1.7, created on 2012-08-13 22:46:23
         compiled from "templates/menuLateral/races/elfe.tpl" */ ?>
<?php /*%%SmartyHeaderCode:14453866555026c40011aeb3-58449501%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e8ce8e9d6ea105ea92134a2e8520d1d5034e8667' => 
    array (
      0 => 'templates/menuLateral/races/elfe.tpl',
      1 => 1344890724,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '14453866555026c40011aeb3-58449501',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5026c40014e9c',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5026c40014e9c')) {function content_5026c40014e9c($_smarty_tpl) {?><div class="descriptionClasse">
<h3>Les Elfes</h3>
<p>Les elfes sont des êtres nobles et fiers. Ils sont blonds avec de longues oreilles.</p>
<h4>Traits raciaux</h4>
<p>+1 en intelligence, +1 en charisme, +1 au dé de toucher avec tous les sorts, vision nocturne développée, taille moyenne.</p>
<h4>Classes disponibles</h4>
<p><a href="?Page=menuLateral/classes/clerc">Clerc</a>, <a href="?Page=menuLateral/classes/druide">druide</a>, 
<a href="?Page=menuLateral/classes/guerrier">guerrier</a>, <a href="?Page=menuLateral/classes/magicien">magicien</a>, <a href="?Page=menuLateral/classes/rodeur">rôdeur</a>,
<a href="?Page=menuLateral/classes/roublard">roublard</a>, <a href="?Page=menuLateral/classes/sombregarde">sombregarde</a>, <a href="?Page=menuLateral/classes/sorcier">sorcier</a>.</p>
</div>

<div class="classeImage">
    <p><img class="imagePersonnage" src="ressources/draconide.jpg"></p>
    <p>Une elfe rôdeuse</p>
</div>
<?php }} ?>
<?php /* Smarty version Smarty-3.1.7, created on 2012-09-22 14:57:58
         compiled from "templates/menu.tpl" */ ?>
<?php /*%%SmartyHeaderCode:3570338744fa149d2ee8bb3-46926445%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b6da4162c469d98c5e879f8e0b21e18d44108090' => 
    array (
      0 => 'templates/menu.tpl',
      1 => 1348318675,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3570338744fa149d2ee8bb3-46926445',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_4fa149d2f0c26',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_4fa149d2f0c26')) {function content_4fa149d2f0c26($_smarty_tpl) {?>
<p>
<a href="?Page=accueil"><span class="menuElement">Accueil</span></a>

<br />
<span class="menuParent">Personnages</span>
<a href="?Page=menuLateral/creation"><span class="menuElement">Création</span></a>
<a href="?Page=menuLateral/classes"><span class="menuElement">Classes</span></a>
<a href="?Page=menuLateral/races"><span class="menuElement">Races</span></a>

<br />
<span class="menuParent">Attributs</span>
<a href="?Page=menuLateral/alignement"><span class="menuElement">Alignement</span></a>
<a href="?Page=menuLateral/dons"><span class="menuElement">Dons</span></a>
<a href="?Page=menuLateral/caracteristiques"><span class="menuElement">Caractéristiques</span></a>
<a href="?Page=menuLateral/competences"><span class="menuElement">Compétences</span></a>

<br />
<span class="menuParent">Monde</span>
<a href="?Page=menuLateral/telneria"><span class="menuElement">Telneria</span></a>
<a href="?Page=menuLateral/equipement"><span class="menuElement">Équipement</span></a>
<a href="?Page=menuLateral/monstres"><span class="menuElement">Monstres</span></a>

<br />
<span class="menuParent">Le jeu</span>
<a href="?Page=menuLateral/experience"><span class="menuElement">Expérience</span></a>
<a href="?Page=menuLateral/combat"><span class="menuElement">Combat</span></a>
</p>

        <?php }} ?>
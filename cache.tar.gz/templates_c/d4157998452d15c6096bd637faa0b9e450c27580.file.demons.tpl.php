<?php /* Smarty version Smarty-3.1.7, created on 2012-08-11 23:39:17
         compiled from "templates/menuLateral/monstres/demons.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2997132115026d1052114f2-10160217%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd4157998452d15c6096bd637faa0b9e450c27580' => 
    array (
      0 => 'templates/menuLateral/monstres/demons.tpl',
      1 => 1344709008,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2997132115026d1052114f2-10160217',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5026d10521226',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5026d10521226')) {function content_5026d10521226($_smarty_tpl) {?><?php }} ?>
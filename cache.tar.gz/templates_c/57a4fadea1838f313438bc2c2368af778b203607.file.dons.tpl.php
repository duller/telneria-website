<?php /* Smarty version Smarty-3.1.7, created on 2012-08-12 14:33:16
         compiled from "templates/menuLateral/dons.tpl" */ ?>
<?php /*%%SmartyHeaderCode:5502331935026aa609f53a7-61062682%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '57a4fadea1838f313438bc2c2368af778b203607' => 
    array (
      0 => 'templates/menuLateral/dons.tpl',
      1 => 1344774795,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '5502331935026aa609f53a7-61062682',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5026aa60a23d4',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5026aa60a23d4')) {function content_5026aa60a23d4($_smarty_tpl) {?><h1>Les dons</h1>
<br />

<p>Chaque don n'est utilisable qu'une seule fois par combat, c'est une demi-action. Sachant qu'un joueur n'a que deux dons au total, il ne peut en utiliser que deux pendant un combat.</p>
<p>Quand les dons modifient des valeurs en pourcentages, on arrondit à la valeur au-dessus.</p>
<br />

<h2>Les dons de sauvegarde
    <h3>Feindre la mort</h3>
<p>Suite à un coup mortel, c'est-à-dire qui amène le joueur sous la barre de 1 point de vie, le joueur lance 1d20 et survit s'il fait au moins 10. 
    Il reste capable de se battre et garde son équilibre.</p><br />
 <h3>Esquive améliorée</h3>
<p>Augmente la classe d'armure de 50% pour les deux prochaines attaques subies.</p><br />
 <h3>Résistance améliorée</h3>
<p>Réduit les dégâts subis par les attaques subies de moitié pour les deux prochaines attaques.</p><br />
<br />

<h2>Les dons de combat</h2>
 <h3>Précision de l'aigle</h3>
<p>Augmente le score obtenu au d20 de toucher de mếlée et à distance de 30% pour les deux prochaines attaques.</p><br />
 <h3>Force de l'ours</h3>
<p>Augmente les dégâts infligés en mêlée ou à distance de 30% pour les deux prochaines attaques.</p><br />
 <h3>Détection du point faible</h3>
<p>Augmente les chances d'infliger un coup critique en réduisant le niveau de critique à 15 pour les deux prochaines attaques.</p><br />
<br />

<h2>Les dons de magie</h2>
 <h3>Augmentation du mana</h3>
<p>Augmente le total des points de mana de 50% pendant deux tours.</p><br />
 <h3>Réduction du coût en mana</h3>
<p>Réduit le coût des sorts de 20% pour les deux prochains sorts.</p><br />
 <h3>Affinité des arcanes</h3>
<p>Augmente le score obtenu au d20 de toucher des sorts de 3 pour les deux prochains sorts.</p><br /><?php }} ?>
<?php /* Smarty version Smarty-3.1.7, created on 2012-07-27 21:59:07
         compiled from "templates/mentionslegales.tpl" */ ?>
<?php /*%%SmartyHeaderCode:6315315525012f30be5d9b8-70650324%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '494b95f1af5b09bc3d7e979c98165929202360fe' => 
    array (
      0 => 'templates/mentionslegales.tpl',
      1 => 1343418991,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6315315525012f30be5d9b8-70650324',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5012f30bec744',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5012f30bec744')) {function content_5012f30bec744($_smarty_tpl) {?>
<h1>Mentions légales</h1>
<p>L'ensemble du contenu de ce site internet est sous licence GPL V3 et CC-by-nc-sa 2.0</p><?php }} ?>
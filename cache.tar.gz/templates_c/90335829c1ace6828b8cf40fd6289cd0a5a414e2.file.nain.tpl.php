<?php /* Smarty version Smarty-3.1.7, created on 2012-08-13 22:46:13
         compiled from "templates/menuLateral/races/nain.tpl" */ ?>
<?php /*%%SmartyHeaderCode:7200512805026c3fe1129d8-81271606%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '90335829c1ace6828b8cf40fd6289cd0a5a414e2' => 
    array (
      0 => 'templates/menuLateral/races/nain.tpl',
      1 => 1344890770,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '7200512805026c3fe1129d8-81271606',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5026c3fe141fa',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5026c3fe141fa')) {function content_5026c3fe141fa($_smarty_tpl) {?><div class="descriptionClasse">
<h3>Les Nains</h3>
<p>Les nains sont de robustes créatures des montagnes.</p>
<h4>Traits raciaux</h4>
<p>+1 en force, +1 en constitution, +1 au dé de toucher avec les haches et les masses, forte réssitance à l'alcool, taille moyenne.</p>
<h4>Classes disponibles</h4>
<p><a href="?Page=menuLateral/classes/clerc">Clerc</a>, <a href="?Page=menuLateral/classes/guerrier">guerrier</a>, <a href="?Page=menuLateral/classes/paladin">paladin</a>,
    <a href="?Page=menuLateral/classes/rodeur">rôdeur</a>, <a href="?Page=menuLateral/classes/roublard">roublard</a>.</p>
</div>

<div class="classeImage">
    <p><img class="imagePersonnage" src="ressources/draconide.jpg"></p>
    <p>Un nain clerc</p>
</div>
<?php }} ?>
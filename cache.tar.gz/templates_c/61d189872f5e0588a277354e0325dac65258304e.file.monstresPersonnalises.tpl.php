<?php /* Smarty version Smarty-3.1.7, created on 2012-09-22 19:43:29
         compiled from "templates/menuLateral/monstres/monstresPersonnalises.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1106342087505df8c1c907e8-18538365%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '61d189872f5e0588a277354e0325dac65258304e' => 
    array (
      0 => 'templates/menuLateral/monstres/monstresPersonnalises.tpl',
      1 => 1348334810,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1106342087505df8c1c907e8-18538365',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_505df8c1ccb98',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_505df8c1ccb98')) {function content_505df8c1ccb98($_smarty_tpl) {?><h1>Les monstres personnalisés</h1><?php }} ?>
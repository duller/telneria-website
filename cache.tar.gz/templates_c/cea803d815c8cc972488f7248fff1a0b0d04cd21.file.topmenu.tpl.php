<?php /* Smarty version Smarty-3.1.7, created on 2012-08-11 20:43:37
         compiled from "templates/layout/topmenu.tpl" */ ?>
<?php /*%%SmartyHeaderCode:9303304335026a7d91ab693-39219728%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'cea803d815c8cc972488f7248fff1a0b0d04cd21' => 
    array (
      0 => 'templates/layout/topmenu.tpl',
      1 => 1344710063,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9303304335026a7d91ab693-39219728',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5026a7d91ae65',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5026a7d91ae65')) {function content_5026a7d91ae65($_smarty_tpl) {?>

<form action="?Page=fiches/recherche" method="POST">
    <label for="tb_recherche">Recherche</label>
    <select>
        <option value="tous">Tous les livres</option>
        <option value="poche">Livres de poche</option>
        <option value="broche">Livres brochés</option>
        <option value="relie">Livres reliés</option>
    </select>
    <input id="tb_recherche" type="text">
    <input onclick="alert('Non implementé')" type="submit">
</form><?php }} ?>
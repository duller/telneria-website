<?php /* Smarty version Smarty-3.1.7, created on 2012-08-26 17:09:03
         compiled from "templates/menuLateral/races/draconide.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1600736230502967b7208c26-34028031%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ecc3da17f7f7b754a5721aec739761c596b9165c' => 
    array (
      0 => 'templates/menuLateral/races/draconide.tpl',
      1 => 1345993733,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1600736230502967b7208c26-34028031',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_502967b723709',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_502967b723709')) {function content_502967b723709($_smarty_tpl) {?><div class="descriptionClasse">
<h3>Les Draconides</h3>
<p>Les draconides sont des humanoïdes issus des dragons, ils ont le corps recouvert d'écailles et une tête reptilienne.</p>
<h4>Traits raciaux</h4>
<p>+1 en constitution, +1 en dextérité, peut respirer sous l'eau, résistant aux fortes chaleurs ainsi qu'au froid, taille moyenne.</p>
<h4>Classes disponibles</h4>
<p><a href="?Page=menuLateral/classes/chaman">Chaman</a>, <a href="?Page=menuLateral/classes/guerrier">guerrier</a>, <a href="?Page=menuLateral/classes/magicien">magicien</a>,
<a href="?Page=menuLateral/classes/sombregarde">sombregarde</a>, <a href="?Page=menuLateral/classes/sorcier">sorcier</a>.</p>
</div>

<div class="classeImage">
    <p><img class="imagePersonnage" src="ressources/ImagesRaces/DraconideSombregarde.jpg"></p>
    <p>Un draconide sombregarde</p>
</div>

<?php }} ?>
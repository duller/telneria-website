<?php /* Smarty version Smarty-3.1.7, created on 2012-09-22 19:26:58
         compiled from "templates/menuLateral/monstres/humanoides.tpl" */ ?>
<?php /*%%SmartyHeaderCode:16468278785026b19fd678e6-58182174%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3dd4ae403cd8664f437f82b59bf127f355065673' => 
    array (
      0 => 'templates/menuLateral/monstres/humanoides.tpl',
      1 => 1348334810,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '16468278785026b19fd678e6-58182174',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5026b19fd6858',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5026b19fd6858')) {function content_5026b19fd6858($_smarty_tpl) {?><h1>Les humanoïdes</h1><?php }} ?>
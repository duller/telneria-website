<?php /* Smarty version Smarty-3.1.7, created on 2012-08-11 15:35:51
         compiled from "templates/classesJdr.tpl" */ ?>
<?php /*%%SmartyHeaderCode:57166306150265a275c00f0-56063497%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0096a07b4479699433372b3099b4237f2453c617' => 
    array (
      0 => 'templates/classesJdr.tpl',
      1 => 1344692149,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '57166306150265a275c00f0-56063497',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_50265a275f604',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_50265a275f604')) {function content_50265a275f604($_smarty_tpl) {?><h1>Les classes</h1>

<p>
<a href="?Page=classesJdr/clerc"> Le Clerc</a>
<br />Le clerc est un homme saint, il cherche à porter assistance à autrui et à transmettre la parole divine.
</p>
<br />

<p>
<a href="?Page=classesJdr/sorcier"> Le Sorcier</a>
<br />Le sorcier est un serviteur du mal.
</p>
<br />

<p>
<a href="?Page=classesJdr/magicien"> Le Magicien</a>
<br />Le magicien maîtrise la magie élémentaire et des arcanes comme personne.
</p>
<br />

<p>
<a href="?Page=classesJdr/roublard"> Le Roublard</a>
<br />Le roublard est un combattant agile et pernicieux, il attaquera habituellement par derrière et se faufile dans l'ombre comme personne.
</p>
<br />

<p>
<a href="?Page=classesJdr/druide"> Le Druide</a>
<br />Le druide communie avec la nature, il peut se transformer en diverses formes animales.
</p>
<br />

<p>
<a href="?Page=classesJdr/rodeur"> Le Rôdeur</a>
<br />Le rôdeur est un tireur habile ainsi qu'un grand connaisseur des bêtes et des forêts.
</p>
<br />

<p>
<a href="?Page=classesJdr/chaman"> Le Chaman</a>
<br />Le chaman est un guide spirituel. Il communique avec les éléments et la nature.
</p>
<br />

<p>
<a href="?Page=classesJdr/guerrier"> Le Guerrier</a>
<br />Le guerrier est un combattant polyvalent et résistant. Il est apte à manier tout type d'armes pour tout combat.
</p>
<br />

<p>
<a href="?Page=classesJdr/paladin"> Le Paladin</a>
<br />Le paladin est un héraut de la lumière, c'est un combattant qui s'est dévoué à combattre le mal.
</p>
<br />

<p>
<a href="?Page=classesJdr/sombregarde"> Le Sombregarde</a>
<br />Le sombregarde est à l'instar du sorcier un serviteur du mal, il est cependant plus axé vers le combat.
</p>
<br /><?php }} ?>
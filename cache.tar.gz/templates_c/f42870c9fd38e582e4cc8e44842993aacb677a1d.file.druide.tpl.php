<?php /* Smarty version Smarty-3.1.7, created on 2012-08-11 15:26:09
         compiled from "templates/classesJdr/druide.tpl" */ ?>
<?php /*%%SmartyHeaderCode:199762030150265d710dbf15-68871068%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f42870c9fd38e582e4cc8e44842993aacb677a1d' => 
    array (
      0 => 'templates/classesJdr/druide.tpl',
      1 => 1344691055,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '199762030150265d710dbf15-68871068',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_50265d7110bef',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_50265d7110bef')) {function content_50265d7110bef($_smarty_tpl) {?>
	<h4>Description</h4>
	<p>
	</p>

	<h4>Armures</h4>
	<p>Tissu, cuir.</p>

	<h4>Armes</h4>
	<p>dagues, toutes masses, bâtons.</p>

	<h4>Alignement</h4>
	<p>Habituellement loyal neutre, ne peut être mauvais.</p>

	<h4>Caractéristiques</h4>
	<p>
	<table>
		<tr>
			<td>
				<p class="ptab">Base de points de vie</p>
			</td>
			<td>
				<p class="ptab">4</p>
			</td>
		</tr>
		<tr>
			<td>
				<p class="ptab">Base de points de mana</p>
			</td>
			<td>
				<p class="ptab">4</p>
			</td>
		</tr>
	</table>
	<br />
	<table>
		<tr>
			<td>
				<p class="ptab">Force</p>
			</td>
			<td>
				<p class="ptab">5</p>
			</td>
		</tr>
		<tr>
			<td>
				<p class="ptab">Dexterité</p>
			</td>
			<td>
				<p class="ptab">6</p>
			</td>
		</tr>
		<tr>
			<td>
				<p class="ptab">Constitution</p>
			</td>
			<td>
				<p class="ptab">6</p>
			</td>
		</tr>
		<tr>
			<td>
				<p class="ptab">Intelligence</p>
			</td>
			<td>
				<p class="ptab">8</p>
			</td>
		</tr>
		<tr>
			<td>
				<p class="ptab">Sagesse</p>
			</td>
			<td>
				<p class="ptab">9</p>
			</td>
		</tr>
		<tr>
			<td>
				<p class="ptab">Charisme</p>
			</td>
			<td>
				<p class="ptab">6</p>
			</td>
		</tr>
	</table>

	
	<br />

	</p>

	<h4>Dons</h4>
	<p>Sauvegarde, combat, magie.</p>

	<h4>Compétences</h4>
	<p>Détection, premiers secours, concentration.</p>

	<h4>Sorts et techniques</h4>
	<p>1 en magie blanche, 1 en magie protectrice, 1 en magie incitatrice, 1 en magie élémentaire.</p>

	<h4>Classes de prestige</h4>
	<p>Farouche, naturaliste.</p>

	<h4>Spécificités</h4>
	<p>Peut se transformer en ours, ce qui empêche le druide de lancer des sorts mais lui confère un bonus de 5 à la force et 5 à la constitution, coût 2 en mana.</p>
<?php }} ?>
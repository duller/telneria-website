<?php /* Smarty version Smarty-3.1.7, created on 2012-08-12 14:32:04
         compiled from "templates/menuLateral/experience.tpl" */ ?>
<?php /*%%SmartyHeaderCode:6676333465026ab6e852943-33926161%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7e2bf78ae5429772e23d38381d252069abd7f323' => 
    array (
      0 => 'templates/menuLateral/experience.tpl',
      1 => 1344774723,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6676333465026ab6e852943-33926161',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5026ab6e884f7',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5026ab6e884f7')) {function content_5026ab6e884f7($_smarty_tpl) {?><h1>L'expérience</h1> 

<h2>Les points d'expérience</h2>
<p>Les joueurs gagnent de l'expérience lorsqu'ils participent à un combat qui résulte en la mort d'une créature.</p>
<p>Les points d'expérience octroyés sont à l'appréciation du MJ.</p>
<p>Il faut acquérir 100 points d'expérience pour passer au niveau suivant. 
    Les points d'expérience continuent à augmenter, il faut attendre 200 points d'expériences pour passer au niveau 3 et ainsi de suite. </p>
<br />

<h2>Les niveaux</h2>
<p>À chaque niveau, les joueurs gagnent 1d2 de chaque caractéristique et 2d2 points de compétences à distribuer. 
    Le maximum de chaque compétence monte d'un point chaque niveau pair.</p>
<p>À chaque niveau, le nombre de points de vie et de mana augmente de 1d4 plus le modificateur respectivement de constitution et d'intelligence.</p><?php }} ?>
<?php /* Smarty version Smarty-3.1.7, created on 2012-08-11 15:26:13
         compiled from "templates/classesJdr/chaman.tpl" */ ?>
<?php /*%%SmartyHeaderCode:192032504750265d757fb011-80609220%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '867c6584c42f26703a7824a7725017f3bf2b36b3' => 
    array (
      0 => 'templates/classesJdr/chaman.tpl',
      1 => 1344690947,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '192032504750265d757fb011-80609220',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_50265d7582b88',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_50265d7582b88')) {function content_50265d7582b88($_smarty_tpl) {?>
    <h4>Description</h4>
    <p>
    </p>

    <h4>Armures</h4>
    <p>Tissu, cuir, maille, bouclier.</p>

    <h4>Armes</h4>
    <p>Dagues, toutes haches, bâtons, toutes masses.</p>

    <h4>Alignement</h4>
    <p>habituellement neutre bon.</p>

    <h4>Caractéristiques</h4>
    <p>
    <table>
            <tr>
                    <td>
                            <p class="ptab">Base de points de vie</p>
                    </td>
                    <td>
                            <p class="ptab">4</p>
                    </td>
            </tr>
            <tr>
                    <td>
                            <p class="ptab">Base de points de mana</p>
                    </td>
                    <td>
                            <p class="ptab">4</p>
                    </td>
            </tr>
    </table>
    <br />
    <table>
            <tr>
                    <td>
                            <p class="ptab">Force</p>
                    </td>
                    <td>
                            <p class="ptab">6</p>
                    </td>
            </tr>
            <tr>
                    <td>
                            <p class="ptab">Dexterité</p>
                    </td>
                    <td>
                            <p class="ptab">6</p>
                    </td>
            </tr>
            <tr>
                    <td>
                            <p class="ptab">Constitution</p>
                    </td>
                    <td>
                            <p class="ptab">6</p>
                    </td>
            </tr>
            <tr>
                    <td>
                            <p class="ptab">Intelligence</p>
                    </td>
                    <td>
                            <p class="ptab">7</p>
                    </td>
            </tr>
            <tr>
                    <td>
                            <p class="ptab">Sagesse</p>
                    </td>
                    <td>
                            <p class="ptab">7</p>
                    </td>
            </tr>
            <tr>
                    <td>
                            <p class="ptab">Charisme</p>
                    </td>
                    <td>
                            <p class="ptab">8</p>
                    </td>
            </tr>
    </table>


    <br />

    </p>

    <h4>Dons</h4>
    <p>Sauvegarde, combat, magie.</p>

    <h4>Compétences</h4>
    <p>Concentration, premiers secours, psychologie.</p>

    <h4>Sorts et techniques</h4>
    <p>1 en magie blanche, 1 en magie protectrice, 1 en magie incitatrice, 1 en magie élémentaire.</p>

    <h4>Classes de prestige</h4>
    <p>Totemiste, mentaliste.</p>

<?php }} ?>
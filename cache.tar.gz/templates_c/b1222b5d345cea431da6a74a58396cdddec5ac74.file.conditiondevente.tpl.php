<?php /* Smarty version Smarty-3.1.7, created on 2012-08-11 13:42:49
         compiled from "templates/conditiondevente.tpl" */ ?>
<?php /*%%SmartyHeaderCode:90921385550264539688558-47039484%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b1222b5d345cea431da6a74a58396cdddec5ac74' => 
    array (
      0 => 'templates/conditiondevente.tpl',
      1 => 1343420742,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '90921385550264539688558-47039484',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_502645396cd15',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_502645396cd15')) {function content_502645396cd15($_smarty_tpl) {?>
<h1>Conditions de vente</h1>

<p>Conditions à établir pour une mise en production</p><?php }} ?>
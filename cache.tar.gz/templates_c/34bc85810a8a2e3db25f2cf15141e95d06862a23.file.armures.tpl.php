<?php /* Smarty version Smarty-3.1.7, created on 2012-08-11 22:55:08
         compiled from "templates/menuLateral/equipement/armures.tpl" */ ?>
<?php /*%%SmartyHeaderCode:6260384475026ab1a4726a6-85796283%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '34bc85810a8a2e3db25f2cf15141e95d06862a23' => 
    array (
      0 => 'templates/menuLateral/equipement/armures.tpl',
      1 => 1344718506,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6260384475026ab1a4726a6-85796283',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5026ab1a4a13c',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5026ab1a4a13c')) {function content_5026ab1a4a13c($_smarty_tpl) {?> i. Les boucliers<br />
Bouclier en bois, 1CA, -1 dégât, 40po.<br />
Bouclier en bronze, 2CA, -2 dégâts, 80po.<br />
Bouclier en acier, 3 CA, -3 dégâts, 120po.<br /><br />
 ii. Le tissu<br />
Robe en soie légère, -1 dégât, 10po.<br />
Tunique en étoffe de laine, -1 dégâts, +1 int, 20 po.<br />
Grande tenue d'apparat, -1 dégâts, +1 int, +1 sag, 30 po.<br /><br />
 iii. Le cuir<br />
Plastron en cuir de sanglier, 1 CA, -1 dégât, 40 po.<br />
Poitrail en peau d'ours, 1 CA, -2 dégâts, 50 po.<br />
Armure de torse en poil de troll, 1 CA, -2 dégâts, +1 agi, 60 po.<br /><br />
 iv. La maille<br />
Tenue en mailles légère, 2 CA, -1 dégât, 50 po.<br />
Tenue en écaille de basilic forgées, 2 CA, -2 dégâts, 60 po.<br />
Plastron en mithril, 2 CA, -2 dégâts, +1 agi, 70 po.<br /><br />
 v. La plaque<br />
Armure de plaques en acier, 3 CA, -2 dégâts, 70 po.<br />
Armure complète en thorium, 3 CA, -3 dégâts, 80po.<br />
Armure en écaille de dragon rouge, 3 CA, -3 dégâts, +1 con, 90po.<br /><?php }} ?>
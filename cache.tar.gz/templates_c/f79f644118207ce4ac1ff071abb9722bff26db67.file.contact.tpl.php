<?php /* Smarty version Smarty-3.1.7, created on 2012-08-11 13:42:56
         compiled from "templates/contact.tpl" */ ?>
<?php /*%%SmartyHeaderCode:203500624550264540f37e71-30164417%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f79f644118207ce4ac1ff071abb9722bff26db67' => 
    array (
      0 => 'templates/contact.tpl',
      1 => 1343420742,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '203500624550264540f37e71-30164417',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_50264541026f1',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_50264541026f1')) {function content_50264541026f1($_smarty_tpl) {?>

<h1>Contacts</h1>
<p>François RIPP</p><?php }} ?>
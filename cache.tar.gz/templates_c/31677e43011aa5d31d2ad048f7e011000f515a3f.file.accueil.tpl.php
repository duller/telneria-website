<?php /* Smarty version Smarty-3.1.7, created on 2012-07-27 22:49:59
         compiled from "templates/accueil.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1618300764fa149d2f12466-60959420%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '31677e43011aa5d31d2ad048f7e011000f515a3f' => 
    array (
      0 => 'templates/accueil.tpl',
      1 => 1343420742,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1618300764fa149d2f12466-60959420',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_4fa149d2f16e9',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_4fa149d2f16e9')) {function content_4fa149d2f16e9($_smarty_tpl) {?>
<h1>Accueil</h1>

<p>Bienvenue sur le site internet du jeu de rôle "Les légendes de Telneria"</p><?php }} ?>
<?php /* Smarty version Smarty-3.1.7, created on 2012-09-22 14:36:25
         compiled from "templates/menuLateral/races/chepteg.tpl" */ ?>
<?php /*%%SmartyHeaderCode:14672847315026c3f8863210-11707726%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b04a35f8aa3dbb5810866c0f4b7a92293950ba1a' => 
    array (
      0 => 'templates/menuLateral/races/chepteg.tpl',
      1 => 1345993733,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '14672847315026c3f8863210-11707726',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5026c3f88947c',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5026c3f88947c')) {function content_5026c3f88947c($_smarty_tpl) {?><div class="descriptionClasse">
<h3>Les Chepteg</h3>
<p>Les chepteg sont des humanoïdes intégralement recouverts de poils, ils ont une mâchoire très étroite mais des griffes puissantes.</p>
<h4>Traits raciaux</h4>
<p>+1 à la dextérité, +1 au dé de toucher avec les arcs et les lances, 1d4 supplémentaire au dé de toucher si les pv du chepteg sont inférieurs à 20% du total, taille moyenne.</p>
<h4>Classes disponibles</h4>
<p><a href="?Page=menuLateral/classes/chaman">Chaman</a>, <a href="?Page=menuLateral/classes/druide">druide</a>, <a href="?Page=menuLateral/classes/guerrier">guerrier</a>,
    <a href="?Page=menuLateral/classes/magicien">magicien</a>, <a href="?Page=menuLateral/classes/rodeur">rôdeur</a>, <a href="?Page=menuLateral/classes/roublard">roublard</a>.</p>
</div>

<div class="classeImage">
    <p><img class="imagePersonnage" src="ressources/ImagesRaces/CheptegChaman.jpg"></p>
    <p>Un chepteg chaman</p>
</div><?php }} ?>
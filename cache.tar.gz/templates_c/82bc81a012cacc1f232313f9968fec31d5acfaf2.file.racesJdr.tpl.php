<?php /* Smarty version Smarty-3.1.7, created on 2012-08-11 18:53:02
         compiled from "templates/racesJdr.tpl" */ ?>
<?php /*%%SmartyHeaderCode:14707746425026612ae2ede2-91325720%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '82bc81a012cacc1f232313f9968fec31d5acfaf2' => 
    array (
      0 => 'templates/racesJdr.tpl',
      1 => 1344703981,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '14707746425026612ae2ede2-91325720',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5026612ae64b2',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5026612ae64b2')) {function content_5026612ae64b2($_smarty_tpl) {?><h1>Les races</h1>

<div>
<h3>Les Orcs</h3>
<p>Les orcs sont de robustes combattants à la peau verte.</p>
<h4>Traits raciaux</h4>
<p>+1 à la force, +1 à la constitution, +1 au dé de toucher avec les haches, 1d4 supplémentaire aux dégâts si les pv de l'orc sont inférieurs à 20% du total, taille moyenne.</p>
<h4>Classes disponibles</h4>
<p>sorcier, chaman, guerrier, sombregarde.</p>
</div>

<br />

<div>
<h3>Les Chepteg</h3>
<p>Les chepteg sont grands et forts, ils sont doués tout aussi bien au combat qu'à la maîtrise de la magie.</p>
<h4>Traits raciaux</h4>
<p>+1 à la dextérité, +1 au dé de toucher avec les arcs et les lances, 1d4 supplémentaire au dé de toucher si les pv du chepteg sont inférieurs à 20% du total, taille moyenne.</p>
<h4>Classes disponibles</h4>
<p>magicien, roublard, druide, chaman, rôdeur, guerrier.</p>
</div>

<br />

<div>
<h3>Les Varelias</h3>
<p>Les varelias sont d'imposants humanoïdes dont l'épiderme s'apparente à l'écorce des arbres. Ils sont proches de la nature, anciens et sages.</p>
<h4>Traits raciaux</h4>
<p>+1 à la constitution, +1 à la force, +1 en sagesse, +1 au dé de toucher avec les sorts de soins, peut s'imprégner de la nature pour recouvrer 1d4 de vie après un combat s'il se situe à proximité de la végétation, taille grande.</p>
<h4>Classes disponibles</h4>
<p>druide, rôdeur, chaman, guerrier.</p>
</div>

<br />

<div>
<h3>Les Murviens</h3>
<p>Les murviens sont des créatures humanoïdes à quatre bras et quatre yeux qui peuvent se régénérer et qui ont une affinité avec la magie offensive.</p>
<h4>Traits raciaux</h4>
<p>+1 au dé de toucher avec les sorts offensifs, respire sous l'eau, peut récupérer 1d4 de vie recouvrée après un combat, insensible à la peur et au charme, taille moyenne.</p>
<h4>Classes disponibles</h4>
<p>magicien, sorcier, roublard, rôdeur.</p>
</div>

<br />

<div>
<h3>Les Elfes</h3>
<p>Les elfes sont des êtres nobles et fiers. Ils sont blonds avec de longues oreilles.</p>
<h4>Traits raciaux</h4>
<p>+1 en intelligence, +1 en charisme, +1 au dé de toucher avec tous les sorts, vision nocturne développée, taille moyenne.</p>
<h4>Classes disponibles</h4>
<p>clerc, magicien, sorcier, druide, roublard, rôdeur, guerrier, sombregarde.</p>
</div>

<br />

<div>
<h3>Les Humains</h3>
<p>Les humains sont des créatures communes et classiques.</p>
<h4>Traits raciaux</h4>
<p>+1 en sagesse, +1 au dé de toucher avec les masses et les épées, taille moyenne.</p>
<h4>Classes disponibles</h4>
<p>clerc, magicien, sorcier, roublard, rôdeur, guerrier, paladin, sombregarde.</p>
</div>

<br />

<div>
<h3>Les Nains</h3>
<p>Les nains sont de robustes créatures des montagnes.</p>
<h4>Traits raciaux</h4>
<p>+1 en force, +1 en constitution, +1 au dé de toucher avec les haches et les masses, forte réssitance à l'alcool, taille moyenne.</p>
<h4>Classes disponibles</h4>
<p>clerc, roublard, rôdeur, guerrier, paladin.</p>
</div>

<br />

<div>
<h3>Les Gnomes</h3>
<p>Les gnomes sont de petites créatures qui comptent sur leur ingéniosité pour compenser leurs faiblesses physiques.</p>
<h4>Traits raciaux</h4>
<p>+1 en intelligence, +1 en sagesse, artisanat amélioré, discrétion améliorée, taille petite.</p>
<h4>Classes disponibles</h4>
<p>magicien, sorcier, roublard.</p>
</div>

<br />

<div>
<h3>Les Neltariens</h3>
<p>Les neltariens sont les cousins sombres des elfes, ils sont plus grands mais conservent une allure élancée.</p>
<h4>Traits raciaux</h4>
<p>+1 en charisme, +1 en dextérité, vision nocturne développée, discrétion améliorée la nuit, taille moyenne.</p>
<h4>Classes disponibles</h4>
<p>magicien, sorcier, roublard, rôdeur, guerrier, sombregarde.</p>
</div>

<br />

<div>
<h3>Les Draconides</h3>
<p>Les draconides sont des humanoïdes issus des dragons, ils ont le corps recouvert d'écailles et une tête reptilienne.</p>
<h4>Traits raciaux</h4>
<p>+1 en constitution, +1 en dextérité, peut respirer sous l'eau, résistant aux fortes chaleurs ainsi qu'au froid, taille moyenne.</p>
<h4>Classes disponibles</h4>
<p>magicien, sorcier, chaman, guerrier, sombregarde.</p>
</div>

<br />

<br />
<h2>Récapitulatif des classes disponibles en fonction des races :</h2>
<br />

<table>
	<tr>
		<td>
		</td>
		<td>
			<p class="ptab">Humain</p>
		</td>
		<td>
			<p class="ptab">Gnome</p>
		</td>
		<td>
			<p class="ptab">Nain</p>
		</td>
		<td>
			<p class="ptab">Elfe</p>
		</td>
		<td>
			<p class="ptab">Orc</p>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Clerc</p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
		</td>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Magicien</p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Sorcier</p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Roublard</p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Rôdeur</p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Druide</p>
		</td>
		<td>
		</td>
		<td>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Chaman</p>
		</td>
		<td>
		</td>
		<td>
		</td>
		<td>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Guerrier</p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Paladin</p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
		</td>
		<td>
		</td>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Sombregarde</p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
	</tr>
</table>

<br />

<table>
	<tr>
		<td>
		</td>
		<td>
			<p class="ptab">Chepteg</p>
		</td>
		<td>
			<p class="ptab">Murvien</p>
		</td>
		<td>
			<p class="ptab">Varelias</p>
		</td>
		<td>
			<p class="ptab">Neltarien</p>
		</td>
		<td>
			<p class="ptab">Draconide</p>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Clerc</p>
		</td>
		</td>
		<td>
		</td>
		<td>
		</td>
		<td>
		</td>
		<td>
		</td>
		<td>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Magicien</p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>

		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Sorcier</p>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Roublard</p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Rôdeur</p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Druide</p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
		</td>
		<td>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Chaman</p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Guerrier</p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Paladin</p>
		</td>
		</td>
		<td>
		</td>
		<td>
		</td>
		<td>
		</td>
		<td>
		</td>
		<td>
		</td>
	</tr>
	<tr>
		<td>
			<p class="ptab">Sombregarde</p>
		</td>
		<td>
		</td>
		<td>
		</td>
		<td>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
		<td>
			<p class="ptab"><input type="checkbox" checked="checked" disabled="true"/></p>
		</td>
	</tr>
</table><?php }} ?>
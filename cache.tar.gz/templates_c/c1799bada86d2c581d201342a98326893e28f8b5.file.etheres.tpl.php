<?php /* Smarty version Smarty-3.1.7, created on 2012-09-22 19:26:56
         compiled from "templates/menuLateral/monstres/etheres.tpl" */ ?>
<?php /*%%SmartyHeaderCode:14813976625027a25f2d8d37-16591284%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c1799bada86d2c581d201342a98326893e28f8b5' => 
    array (
      0 => 'templates/menuLateral/monstres/etheres.tpl',
      1 => 1348334810,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '14813976625027a25f2d8d37-16591284',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.7',
  'unifunc' => 'content_5027a25f2e736',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5027a25f2e736')) {function content_5027a25f2e736($_smarty_tpl) {?><h1>Les éthérés</h1><?php }} ?>
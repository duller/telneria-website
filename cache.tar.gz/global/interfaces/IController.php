<?php


interface IController 
{
    public function execute(Smarty $environnement);
}

?>
